let campoIdade;
let campoRomance;
let campoComédiaeamor;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("16");
  campoFantasia = createCheckbox("Gosta de romance?");
  campoAventura = createCheckbox("Gosta de comédias e amor?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 14) {
      return "Como perder um cara em 10 dias";
    } else {
      if (idade >= 12) {
        if(gostaDeRomance || gostaDeComédiaeAmor) {
          return "Orgulho e preconceito";          
        } else{
         return "Um date perfeito"
        }
      } else {
        if (gostaDeFantasia) {
          return "A 5 passos de você";
        } else {
          return "Cloud 9";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "10 coisas que eu odeio em você";
    } else {
      return "Para todos os garotos que já amei";
    }
  }
}
